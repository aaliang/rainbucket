Bootstrap
=========

Shim repository for [Bootstrap](http://getbootstrap.com).

This package just provides the basic Bootstrap JavaScript in the package. This
means that although the stylesheets are there, you will be required to provide
your own means of including the styles. If you aim to use the default Bootstrap
styles, then you could use the [components/bootstrap-default](http://github.com/components/bootstrap-default)
package for that.

Package Managers
----------------

* [npm](http://npmjs.org/package/components-bootstrap): `components-bootstrap`
* [Bower](http://twitter.github.com/bower/): `components-bootstrap`
* [Component](https://github.com/component/component): `components/bootstrap`
* [Composer](http://packagist.org/packages/components/bootstrap): `components/bootstrap`
